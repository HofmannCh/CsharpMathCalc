﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("HotkeyListener")]
[assembly: AssemblyDescription("A library that provides support for registering and attaching events to global hotkeys in .NET applications.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Willy Kimura")]
[assembly: AssemblyProduct("HotkeyListener")]
[assembly: AssemblyCopyright("Copyright © 2019, Willy Kimura.")]
[assembly: AssemblyTrademark("A product of Willy Kimura.")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("b8b41b35-3d81-4e81-a0d4-24002ef895b9")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.3.0.0")]
[assembly: AssemblyFileVersion("1.3.0.0")]
